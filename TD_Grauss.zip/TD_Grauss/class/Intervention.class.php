<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Intervention
 *
 * @author mmaldo
 */
require_once '/autoload.inc.php';

class Intervention {
    //put your code here
    
    private $_numero;
    private $_date;
    private $_duree;
    private $_tarifKm;
    private $_leTechnicien;
    private $_leContrat;
    
    public function __construct($p_numero, $p_date, $p_duree , $p_tarifKm , Employe $p_leTechnicien , Contrat $p_leContrat)
    {
        $this->_numero = $p_numero;
        $this->_date = $p_date;
        $this->_duree = $p_duree;
        $this->_tarifKm = $p_tarifKm;
        $this->_leTechnicien = $p_leTechnicien;
        $this->_leContrat = $p_leContrat;
        
    }
    
    public function FraisMO()
    {
        return $this->_duree * $this->_leTechnicien->coutHoraire();
    }
    
    public function FraisKm()
    {
        return $this->_leContrat->getClient()->distance() * $this->_tarifKm;
    }   
}
