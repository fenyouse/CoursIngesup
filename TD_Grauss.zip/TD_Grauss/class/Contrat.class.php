<?php

require_once '/autoload.inc.php';

class Contrat {
	private $_numero;
	private $_date;
	private $_montantContrat;
	private $_lesInterventions;
	private $_leClient;

	public function __construct($p_numero, $p_date, $p_montantContrat, Client $p_leClient) {
            $this->_numero = $p_numero;
            $this->_date = $p_date;
            $this->_montantContrat = $p_montantContrat;
            $this->_lesInterventions = Array();
            $this->_leClient = $p_leClient;
	}

	public function getClient() {
            return $this->_leClient;
	}

        public function ajouterIntervention (Intervention $p_nouvelleIntervention)
        {
            $this->_lesInterventions[] = $p_nouvelleIntervention;
        }
	public function Ecart() {
            $total = 0;           
            foreach ($this->_lesInterventions as $uneIntervention )            
                    $total += $uneIntervention->FraisMo() + $uneIntervention->FraisKm();
         
            return  $this->_montantContrat - $total;
	}
}
?>