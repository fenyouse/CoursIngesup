<?php
require_once '/autoload.inc.php';

class Client {    
    private $_numero;
    private $_nom;
    private $_dist;
    private $_sonContrat;

    public function __construct($p_numero, $p_nom, $p_distance)
    {
    	$this->_numero = $p_numero;
    	$this->_nom = $p_nom;
    	$this->_dist = $p_distance;
    }

    public function signerContract(Contrat $p_leContrat)
    {
        $this->_sonContrat = $p_leContrat;
    }

    public function distance()
    {
        return $this->_dist;
    }
}
?>