<?php
require_once '/autoload.inc.php';

class Grade {
   private $_code;
   private $_libelle;
   private $_taux;

   public function __construct($p_code, $p_libelle,$p_taux){
           $this->_code = $p_code;
           $this->_libelle = $p_libelle;
           $this->_taux = $p_taux;

   }
   public function tauxHoraire(){
           return $this->_taux;
   }
}
?>
