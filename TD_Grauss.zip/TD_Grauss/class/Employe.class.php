<?php
require_once '/autoload.inc.php';

class Employe {
    
    private $_numero;
    private $_nom;
    private $_dateEmbauche;
    private $_saQualification;

    public function __construct($p_numero, $p_nom, $p_dateEmbauche, $p_saQualification)
    {
    	$this->_numero = $p_numero;
    	$this->_nom = $p_nom;
    	$this->_dateEmbauche = $p_dateEmbauche;
    	$this->_saQualification = $p_saQualification;
    }

    public function CoutHoraire()
    {
    	return $this->_saQualification->TauxHoraire();
    }
}
?>