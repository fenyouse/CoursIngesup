<?php
function __autoload ($nomClasse)
{
	require_once "/class/" . $nomClasse . ".class.php";
}
?>
