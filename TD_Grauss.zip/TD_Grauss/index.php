<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

require_once ("/autoload.inc.php");

$OHQ = new Grade ("OHQ", "Ouvrier Hautement Qualifie", 40);
$unEmploye = new Employe(5,'Dupont','09/05/2015', $OHQ);

$leClient = new Client(17,'maldonado',50);
$leContrat = new Contrat(12,'1/10/2014',1000,$leClient);
$leClient->signerContract ($leContrat);

$uneIntervention  = new Intervention(1,'03/10/2014', 5 , 1.00, $unEmploye, $leContrat);
$uneAutreIntervention  = new Intervention(1,'10/10/2014', 3 , 1.00, $unEmploye, $leContrat);
$uneTroisiemeIntervention  = new Intervention(1,'25/10/2014', 1 , 1.00, $unEmploye, $leContrat);

$leContrat->ajouterIntervention($uneIntervention);
$leContrat->ajouterIntervention($uneAutreIntervention);
$leContrat->ajouterIntervention($uneTroisiemeIntervention);

$montant = $leContrat->ecart();
if ($montant < 0)
    echo "pertes sur ce contrat : " . $montant . " euros <br/>";
else    
    echo "gains sur ce contrat : " . $montant . " euros <br/>";

?>